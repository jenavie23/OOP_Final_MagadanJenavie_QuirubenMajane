﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace New
{
    class LogIn
    {
         public void ProgramStart()
        {
            //var guid = Guid.NewGuid().ToString();
            //Console.Write(guid);
           
            LogIn l = new LogIn();



           /* foreach (User user in DataSet.UserList)
            {
                Console.WriteLine(user.toString());
            }
            */
        NotLoginHome:

            switch (l.Home())
            {
                case "a":
                case "A":
                    l.Login();
                    break;
                case "b":
                case "B":

                    Logout m = new Logout();
                    m.Out();
                    break;
                default:
                    Console.Clear();

                    Console.WriteLine("\n\nInvalid Choice please select from valid choices\n");

                    goto NotLoginHome;


            };
        }
        public string Home()
        {
            string choice;
            AstDesign(2);
            Console.WriteLine("xxxxx   WELCOME TO CAZA DE MARIA" + Username + "  xxxxxx");
            AstDesign(2);
            Console.WriteLine("*****   Select Option         *******");
            AstDesign(1);
            Console.WriteLine("*****   A. Login          *******");
            Console.WriteLine("*****   B. Logout         *******");
            AstDesign(1);
            Console.Write("*****   Please Select an Option:");
            choice = Console.ReadLine();
            AstDesign(1);
            return choice;
        }
        
        public string LoginHome()
        {
            ChoiceOne c = new ChoiceOne();
            Program p = new Program();
            String input = "";



            {
                Console.WriteLine("xxxxx   WELCOME TO CAZA DE MARIA  xxxxxx");
                Console.WriteLine("*****   Select Option         *******");
                Console.WriteLine("*****   A. Laundry Section          *******");
                Console.WriteLine("*****   B. Housekeeping Section     *******");
                Console.WriteLine("*****   C. Logout                   *******");
                Console.Write("*****   Please Select an Option:");
                input = Console.ReadLine();

                try
                {

                    switch (input)
                    {
                        case "a":
                        case "A":
                            c.Laundry();
                            break;
                        case "b":
                        case "B":
                            ChoiceTwo b = new ChoiceTwo();
                            b.Housekeeping();
                            break;
                        case "c":
                        case "C":
                            Logout m = new Logout();
                            m.Out();
                            break;
                        default:
                            Console.WriteLine("invalid keyword");
                            break;
                    }
                }
                catch
                {

                    Console.Clear();
                    Console.WriteLine("Invalid Credentials !!!");



                }

                return input;

            }
        }
            
            
        public void Login()
        {
            string name = "dai";
            string pass = "two";
            String username, password;
            Console.WriteLine("*****   LOGIN        *******");
            Console.Write("Please Input Username:");
            username = Console.ReadLine();
            Console.Write("Please Input Password:");
            password = Console.ReadLine();
          
            if (username == name & password == pass)
            {
                Console.Clear();
                LoginHome();
            }

            else
            {
                Console.WriteLine("INVALID CREDENTIALS");
                Login();
            
            }
             
        
        }
        
          
            public void AstDesign(byte b)
            {
                for (int a = 1; a <= b; a++)
                {
                    Console.WriteLine("*******************************************");
                }
        }


            public string id { get; set; }

            public string Username { get; set; }
    }
}
