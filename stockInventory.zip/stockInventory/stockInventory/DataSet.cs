﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace New
{
    class DataSet
    {
       
        public static List<LogIn> LoginHome = new List<LogIn>();
        public static List<Stocks> StocksList = new List<Stocks>();
        public static List<ChoiceOne>ChoiceList1 = new List<ChoiceOne>();

    }
}

