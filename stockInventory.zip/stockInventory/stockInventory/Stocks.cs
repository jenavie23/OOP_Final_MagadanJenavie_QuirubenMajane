﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace New
{
    class Stocks
    {
        public byte Stock;
        private byte[] p;
        private byte stock;

        public Stocks(Byte stock)
        {
            this.Stock = stock;
        }

        public Stocks(byte[] p, byte stock)
        {
            // TODO: Complete member initialization
            this.p = p;
            this.stock = stock;
        }
        public String toString()
        {
            return "Stock{" +
                ",Stock =" + Stock +
                '}';
        }
    }
}
