﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace New
{
    class ChoiceTwo
    {
        public void Housekeeping()
        {
            string choice;
            int total;
            try
            {
              

                int num1 = 100;
                int num2 = 105;
                int num3 = 105;
                int num4 = 80;
                int num5 = 100;
                Console.WriteLine("*********************************************************************");
                Console.WriteLine("********************** WELCOME TO  *********************************");
                Console.WriteLine("********************* CAZA DE MARIA *********************************");
                Console.WriteLine("*********************************************************************");
                Console.WriteLine("======================================================================");
                Console.WriteLine("********************       Housekeeping Stock Inventory   ***************");
                Console.WriteLine("********************           List of Items              ***************");
                Console.WriteLine("********************  a. Linens             :  " + num1);
                Console.WriteLine("********************  b. Pillow             : " + num2);
                Console.WriteLine("********************  c. Pillowcase         : " + num3);
                Console.WriteLine("********************  d. Blanket            :  " + num4);
                Console.WriteLine("********************  e. Beddings           : " + num5);
                Console.WriteLine("********************  f. ALL of the Above               *******************");
                Console.WriteLine("===========================================================================");
                Console.WriteLine("***************************************************************************");
                Console.WriteLine("***************************************************************************");


                byte stock;
                Console.WriteLine(" PLEASE CHOOSE FROM THE FOLLOWING STOCKS TO BE LESS. (a,b,c,d,e,f");
                choice = Console.ReadLine();
                if (choice == "a" || choice == "A")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" Linens:");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();
                    Console.WriteLine("     Linens:  " + stock);
                    total = byte.Parse(Console.ReadLine());


                }
                else if (choice == "b" || choice == "B")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" pillow:");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("    pillow  " + (num2 - stock));
                    stock = byte.Parse(Console.ReadLine());
                }
                else if (choice == "c" || choice == "C")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" pillowcase:");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("    pillowcase  " + (num3 - stock));
                    stock = byte.Parse(Console.ReadLine());
                }
                else if (choice == "d" || choice == "D")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" blanket:");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("    blanket  " + (num4 - stock));
                    stock = byte.Parse(Console.ReadLine());
                }
                else if (choice == "e" || choice == "E")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" beddings:");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("    blanket  " + (num5 - stock));
                    stock = byte.Parse(Console.ReadLine());
                }
                else if (choice == "f" || choice == "F")
                {
                    Console.WriteLine(" Less Usage For A Week ");

                    Console.Write(" Linens :");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Write(" Pillow : ");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Write(" Pillowcase :");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Write(" Blanket :");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Write(" Beddings :");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Clear();



                    Console.WriteLine("***********************************************************************************");
                    Console.WriteLine("********************** WELCOME TO  ************************************************");
                    Console.WriteLine("********************* CAZA DE MARIA ***********************************************");
                    Console.WriteLine("***********************************************************************************");
                    Console.WriteLine("===================================================================================");
                    Console.WriteLine("********************       Housekeeping Stock Inventory   *************************");
                    Console.WriteLine("********************    Final Report !!!!                 *************************");


                    Console.WriteLine("     Linens :  " + (num1 - stock));
                    
                    
                    Console.WriteLine("     Pillow : " + (num2 - stock));

                    Console.WriteLine("     Pillowcase :" + (num3 - stock));
                    

                    Console.WriteLine("     Blanket :" + (num4 - stock));


                    Console.WriteLine("     Beddings :" + (num5 - stock));
                    
                    Console.WriteLine("==================================================================================");
                    Console.WriteLine("**********************************************************************************");
                    Console.WriteLine("**********************************************************************************");

                }
                else
                {
                    Console.WriteLine("INVALID CHOICE!!!!");
                    Housekeeping();
                }

            }

            catch
            {

            }

            string option;
            Console.Write("Do you Want to Go Back Home? press (y/Y)");
            Console.WriteLine();
            Console.Write("Or do you want to log out ? press (l/L)");
            option = Console.ReadLine();

            if (option == "y" || option == "Y")
            {
                Console.Clear();
                LogIn l = new LogIn();
                l.LoginHome();

            }
            else if (option == "l" || option == "L")
            {
                Console.Clear();
                Logout m = new Logout();
                m.Out();
            }



        }
        
    }
}
