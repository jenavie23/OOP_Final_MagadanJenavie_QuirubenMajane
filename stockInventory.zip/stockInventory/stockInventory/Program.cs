﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace New
{
    class Program
    {
        static void Main(string[] args)
        {
            LogIn l = new LogIn();
            l.ProgramStart();




            Console.Read();

        }
    }
}
