﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace New
{
    class ChoiceOne
    {

        
        public void Laundry()
        {
            ChoiceOne c = new ChoiceOne();
            string choice;
            try
            {
                int num1 = 10;
                int num2 = 75;
                int num3 = 55;
                int num4 = 80;
                int num5 = 50;
                byte stock = 0;

                Console.WriteLine("******************************************************************");
                Console.WriteLine("********************** WELCOME TO  *******************************");
                Console.WriteLine("********************* CAZA DE MARIA ******************************");
                Console.WriteLine("******************************************************************");
                Console.WriteLine("==================================================================");
                Console.WriteLine("********************       Laundry Stock Inventory        ***********");
                Console.WriteLine("********************           List of Items              ***********");
                Console.WriteLine("********************  a. Laundry Bar Soap    :    " +(num1 - stock));
                Console.WriteLine("********************  b. Laundry Powder           " + num2);
                Console.WriteLine("********************  c. Anti- Oxidant       :    " + num3);
                Console.WriteLine("********************  d. Anti- Bacterial     :    " + num4);
                Console.WriteLine("*******************   e. Softener            :    " + num5);
                Console.WriteLine("*******************   f. ALL of the Above      ");
                Console.WriteLine("=============================================================");
                Console.WriteLine("**************************************************************");
                Console.WriteLine("*************************************************************");



                
                Console.WriteLine("PLEASE  CHOOSE FROM THE FOLLOWING STOCKS TO BE LESS. (a,b,c,d,e,f)");
                choice = Console.ReadLine();

                if (choice == "a" || choice == "A")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" Laundry Bar Soap:");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();
                    num1 = num1 - stock;
                    Console.WriteLine("     Laundry Bar Soap:  " + (num1));
                    int bs = num1 - stock;
                    num1 = bs;
                }
                else if (choice == "b" || choice == "B")
                {
                    Console.WriteLine(" Less Usage For A Week "); 
                    Console.Write(" Laundry Powder: ");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("      Laundry Powder: " + (num2 - stock));

                }
                else if (choice == "c" || choice == "C")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" Anti-Oxidant:");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("     Anti-Oxidant:" + (num3 - stock));

                }
                else if (choice == "d" || choice == "D")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" Anti-Bacterial:");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Clear();
                    Console.WriteLine("     Anti-Bacterial:" + (num4 - stock));

                }
                else if (choice == "e" || choice == "E")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" Softener:");
                    stock = byte.Parse(Console.ReadLine());
                    Console.Clear();

                    Console.WriteLine("     Softener:" + (num5 - stock));

                }
                else if (choice == "f" || choice == "F")
                {
                    Console.WriteLine(" Less Usage For A Week ");
                    Console.Write(" Laundry Bar Soap:");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Write(" Laundry Powder: ");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Write(" Anti-Oxidant:");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Write(" Anti-Bacterial:");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Write(" Softener:");
                    stock = byte.Parse(Console.ReadLine());

                    Console.Clear();

                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("********************** WELCOME TO  *******************************************");
                    Console.WriteLine("********************* CAZA DE MARIA ******************************************");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("********************       Laundry Stock Inventory        ********************");
                    Console.WriteLine("********************    Final Report !!!!                 ********************");


                    Console.WriteLine("     Laundry Bar Soap:  " + (num1 - stock));


                    Console.WriteLine("     Laundry Powder: " + (num2 - stock));


                    Console.WriteLine("     Anti-Oxidant:" + (num3 - stock));

                    Console.WriteLine("     Anti-Bacterial:" + (num4 - stock));


                    Console.WriteLine("     Softener:" + (num5 - stock));

                    Console.WriteLine("================================================================");
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("****************************************************************");


                }
                else
                {
                    Console.WriteLine("INVALID CHOICE!!!!");
                    Laundry();
                }



            }
            catch
            {

            }

            string option;
            Console.Write("Do you Want to Go Back Home? press (y/Y)");
            Console.WriteLine();
            Console.Write("Or do you want to log out ? press (l/L)");
            option = Console.ReadLine();

            if (option == "y" || option == "Y")
            {
                Console.Clear();
                LogIn l = new LogIn();
                l.LoginHome();

            }
            else if (option == "l" || option == "L")
            {
                Console.Clear();
                Logout m = new Logout();
                m.Out();
            }


        }
    }
}
