﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace New
{
    class Logout
    {
        public void Out()
        {
            Console.WriteLine("SUCCESSFULLY LOG OUT");
            Console.Read();

        }
    }
}
